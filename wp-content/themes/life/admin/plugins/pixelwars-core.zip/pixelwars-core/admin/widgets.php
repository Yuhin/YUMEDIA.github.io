<?php

	include_once($pixelwars_core_ABSPATH . 'admin/widget-social-media-icon.php');
	
	include_once($pixelwars_core_ABSPATH . 'admin/widget-social-media-feed.php');
	
	include_once($pixelwars_core_ABSPATH . 'admin/widget-link-box.php');
	
	include_once($pixelwars_core_ABSPATH . 'admin/widget-about-me.php');
	
	include_once($pixelwars_core_ABSPATH . 'admin/widget-intro.php');
	
	include_once($pixelwars_core_ABSPATH . 'admin/widget-main-slider.php');

?>