<?php
/*
Plugin Name: Life Shortcodes
Plugin URI:  http://www.pixelwars.org
Description: Life theme shortcodes.
Version:     1.0
Author:      Pixelwars
Author URI:  http://www.pixelwars.org
License:     ThemeForest License
Text Domain: life-shortcodes
Domain Path: /languages/
*/


/* ============================================================================================================================================= */


	// Don't load directly.
	
	if (! defined('ABSPATH'))
	{
		die('-1');
	}


/* ============================================================================================================================================= */


	function life_shortcodes_load_plugin_textdomain()
	{
		load_plugin_textdomain('life-shortcodes', false, dirname(plugin_basename(__FILE__)) . '/languages');
	}
	
	add_action('init', 'life_shortcodes_load_plugin_textdomain');


/* ============================================================================================================================================= */


	function life_shortcodes_enqueue_css()
	{
		$plugin_directory_url = plugin_dir_url(__FILE__); // http://www.example.com/wp-content/plugins/my-plugin/
		
		wp_enqueue_style('fontello', $plugin_directory_url . 'css/fonts/fontello/css/fontello.css', null, null);
		wp_enqueue_style('life-shortcodes', $plugin_directory_url . 'css/shortcodes.css', array('fontello'), null);
	}
	
	add_action('wp_enqueue_scripts', 'life_shortcodes_enqueue_css', 10);
	
	
	function life_shortcodes_enqueue_js()
	{
		$plugin_directory_url = plugin_dir_url(__FILE__); // http://www.example.com/wp-content/plugins/my-plugin/
		
		wp_enqueue_script('jqueryvalidation', $plugin_directory_url . 'js/jquery-validation/jquery.validate.min.js', array('jquery'), null, true);
		wp_enqueue_script('life-shortcodes', $plugin_directory_url . 'js/shortcodes.js', array('jquery', 'jqueryvalidation'), null, true);
		
		$validator_messages = '(function($) { "use strict";' . PHP_EOL;
		$validator_messages .= '$.extend($.validator.messages, {' . PHP_EOL;
		$validator_messages .= 'required: "' . esc_html__('This field is required.', 'life-shortcodes') . '",' . PHP_EOL;
		$validator_messages .= 'remote: "' . esc_html__('Please fix this field.', 'life-shortcodes') . '",' . PHP_EOL;
		$validator_messages .= 'email: "' . esc_html__('Please enter a valid email address.', 'life-shortcodes') . '",' . PHP_EOL;
		$validator_messages .= 'url: "' . esc_html__('Please enter a valid URL.', 'life-shortcodes') . '",' . PHP_EOL;
		$validator_messages .= 'date: "' . esc_html__('Please enter a valid date.', 'life-shortcodes') . '",' . PHP_EOL;
		$validator_messages .= 'dateISO: "' . esc_html__('Please enter a valid date ( ISO ).', 'life-shortcodes') . '",' . PHP_EOL;
		$validator_messages .= 'number: "' . esc_html__('Please enter a valid number.', 'life-shortcodes') . '",' . PHP_EOL;
		$validator_messages .= 'digits: "' . esc_html__('Please enter only digits.', 'life-shortcodes') . '",' . PHP_EOL;
		$validator_messages .= 'equalTo: "' . esc_html__('Please enter the same value again.', 'life-shortcodes') . '",' . PHP_EOL;
		$validator_messages .= 'maxlength: $.validator.format("' . esc_html__('Please enter no more than {0} characters.', 'life-shortcodes') . '"),' . PHP_EOL;
		$validator_messages .= 'minlength: $.validator.format("' . esc_html__('Please enter at least {0} characters.', 'life-shortcodes') . '"),' . PHP_EOL;
		$validator_messages .= 'rangelength: $.validator.format("' . esc_html__('Please enter a value between {0} and {1} characters long.', 'life-shortcodes') . '"),' . PHP_EOL;
		$validator_messages .= 'range: $.validator.format("' . esc_html__('Please enter a value between {0} and {1}.', 'life-shortcodes') . '"),' . PHP_EOL;
		$validator_messages .= 'max: $.validator.format("' . esc_html__('Please enter a value less than or equal to {0}.', 'life-shortcodes') . '"),' . PHP_EOL;
		$validator_messages .= 'min: $.validator.format("' . esc_html__('Please enter a value greater than or equal to {0}.', 'life-shortcodes') . '"),' . PHP_EOL;
		$validator_messages .= 'step: $.validator.format("' . esc_html__('Please enter a multiple of {0}.', 'life-shortcodes') . '")' . PHP_EOL;
		$validator_messages .= '});' . PHP_EOL;
		$validator_messages .= '})(jQuery);';
		
		wp_add_inline_script('jqueryvalidation', $validator_messages);
	}
	
	add_action('wp_enqueue_scripts', 'life_shortcodes_enqueue_js', 15);


/* ============================================================================================================================================= */


	add_filter('the_excerpt', 'do_shortcode');
	add_filter('widget_text', 'do_shortcode');
	add_filter('category_description', 'do_shortcode');


/* ============================================================================================================================================= */


	function social_icon_html($type, $same_tab, $url)
	{
		$new_tab = 'target="_blank"';
		
		if ($same_tab == 'yes')
		{
			$new_tab = "";
		}
		
		$output = '<a ' . $new_tab . ' class="social-link ' . esc_attr($type) . '" href="' . esc_url($url) . '"></a>';
		
		return $output;
	}
	
	
	function social_icon($atts, $content = "")
	{
		extract(
			shortcode_atts(
				array(
					'type'     => "",
					'same_tab' => "",
					'url'      => "",
					'group'    => ""
				),
				$atts
			)
		);
		
		$output = "";
		
		if (! empty($group))
		{
			$group = vc_param_group_parse_atts($atts['group']);
			
			foreach ($group as $key => $value)
			{
				$type     = $value["type"];
				$same_tab = $value["same_tab"];
				$url      = $value["url"];
				
				$output .= social_icon_html($type, $same_tab, $url);
			}
		}
		else
		{
			$output = social_icon_html($type, $same_tab, $url);
		}
		
		return $output;
	}
	
	add_shortcode('social_icon', 'social_icon');


/* ============================================================================================================================================= */


	function contact_form($atts, $content = "")
	{
		extract(
			shortcode_atts(
				array(
					'to'      => "",
					'subject' => "",
					'captcha' => ""
				),
				$atts
			)
		);
		
		$to = trim($to);
		update_option('life_contact_form_to', $to);
		
		$captcha_html = '<p style="padding: 0px; margin: 0px;"><input type="hidden" id="captcha" name="captcha" value="no"></p>';
		
		if ($captcha == 'yes')
		{
			$random1 = rand(1, 5);
			$random2 = rand(1, 5);
			$sum_random = $random1 + $random2;
			
			$captcha_html  = '<p>';
			$captcha_html .= '<input type="hidden" id="captcha" name="captcha" value="yes">';
			$captcha_html .= '<label for="sum_user">' . $random1 . ' + ' . $random2 . ' = ?</label>';
			$captcha_html .= '<input type="text" id="sum_user" name="sum_user" class="required" placeholder="' . esc_html__('What is the sum?', 'life-shortcodes') . '">';
			$captcha_html .= '<input type="hidden" id="sum_random" name="sum_random" value="' . $sum_random . '">';
			$captcha_html .= '</p>';
		}
		
		$site_url = strtolower($_SERVER['SERVER_NAME']);
		
		if (substr($site_url, 0, 4) == 'www.')
		{
			$site_url = substr($site_url, 4);
		}
		
		$plugin_directory_url = plugin_dir_url(__FILE__); // http://example.com/wp-content/plugins/my-plugin/
		$sender_domain = 'server@' . $site_url;
		
		$output  = '<div class="contact-form">';
		$output .= '<form id="contact-form" class="validate-form" method="post" action="' . $plugin_directory_url . 'send-mail.php">';
		$output .= '<p><label for="name">' . esc_html__('NAME', 'life-shortcodes') . '</label><input type="text" id="name" name="name" class="required"></p>';
		$output .= '<p><label for="email">' . esc_html__('EMAIL', 'life-shortcodes') . '</label><input type="text" id="email" name="email" class="required email"></p>';
		$output .= '<p><label for="message">' . esc_html__('MESSAGE', 'life-shortcodes') . '</label><textarea id="message" name="message" class="required"></textarea></p>';
		$output .= $captcha_html;
		$output .= '<p><button class="submit button"><span class="submit-label">' . esc_html__('Submit', 'life-shortcodes') . '</span><span class="submit-status"></span></button></p>';
		$output .= '<p style="padding: 0px; margin: 0px;"><input type="hidden" id="sender_domain" name="sender_domain" value="' . $sender_domain . '"></p>';
		$output .= '<p style="padding: 0px; margin: 0px;"><input type="hidden" id="subject" name="subject" value="' . esc_attr($subject) . '"></p>';
		$output .= '</form>';
		$output .= '</div>';
		
		return $output;
	}
	
	add_shortcode('contact_form', 'contact_form');


/* ============================================================================================================================================= */


	function quote( $atts, $content = "" )
	{
		extract( shortcode_atts( array( 'name'  => "",
										'align' => "" ), $atts ) );
		
		$output = '<blockquote class="' . $align . '">' . do_shortcode( $content ) . '<cite>' . $name . '</cite></blockquote>';
		
		return $output;
	}
	
	add_shortcode( 'quote', 'quote' );


/* ============================================================================================================================================= */


	function drop_cap( $atts, $content = "" )
	{
		$output = '<p class="drop-cap">' . do_shortcode( $content ) . '</p>';
		
		return $output;
	}
	
	add_shortcode( 'drop_cap', 'drop_cap' );


/* ============================================================================================================================================= */


	if (class_exists('WPBakeryShortCodesContainer'))
	{
		class WPBakeryShortCode_Event_Group_Title extends WPBakeryShortCodesContainer
		{
			public static function event_group_title($atts, $content = "")
			{
				extract(
					shortcode_atts(
						array(
							'icon' => "",
							'text' => ""
						),
						$atts
					)
				);
				
				if (! empty($icon))
				{
					$icon = '<i class="pw-icon-' . $icon . '"></i>';
				}
				
				$output = '<div class="event">';
				$output .= '<h2>' . $text . '</h2>';
				$output .= $icon;
				$output .= do_shortcode($content);
				$output .= '</div>';
				
				return $output;
			}
		}
		
		add_shortcode('event_group_title', array('WPBakeryShortCode_Event_Group_Title', 'event_group_title'));
	}


/* ============================================================================================================================================= */


	function event($atts, $content = "")
	{
		extract(
			shortcode_atts(
				array(
					'current'   => "",
					'date'      => "",
					'title'     => "",
					'sub_title' => ""
				),
				$atts
			)
		);
		
		if ($current == 'true')
		{
			$current = 'current';
		}
		
		$output = '<div class="event ' . esc_attr($current) . '">';
		$output .= '<h6>' . $date . '<h6>';
		$output .= '<h4>' . $title . '</h4>';
		$output .= '<h5>' . $sub_title . '</h5>';
		$output .= '<p>' . do_shortcode($content) . '</p>';
		$output .= '</div>';
		
		return $output;
	}
	
	add_shortcode('event', 'event');


/* ============================================================================================================================================= */


	function skill_html($title, $percent)
	{
		$output = '<div class="skill-unit">';
		$output .= '<h4>' . $title . '</h4>';
		$output .= '<div class="bar" data-percent="' . esc_attr($percent) . '">';
		$output .= '<div class="progress"></div>';
		$output .= '</div>';
		$output .= '</div>';
		
		return $output;
	}
	
	
	function skill($atts, $content = "")
	{
		extract(
			shortcode_atts(
				array(
					'title'   => "",
					'percent' => "",
					'group'   => ""
				),
				$atts
			)
		);
		
		$output = "";
		
		if (! empty($group))
		{
			$group = vc_param_group_parse_atts($atts['group']);
			
			foreach ($group as $key => $value)
			{
				$title   = $value["title"];
				$percent = $value["percent"];
				
				$output .= skill_html($title, $percent);
			}
		}
		else
		{
			$output = skill_html($title, $percent);
		}
		
		return $output;
	}
	
	add_shortcode('skill', 'skill');


/* ============================================================================================================================================= */


	function testimonial($atts, $content = "")
	{
		extract(
			shortcode_atts(
				array(
					'image'     => "",
					'title'     => "",
					'sub_title' => ""
				),
				$atts
			)
		);
		
		if (is_numeric($image))
		{
			$image = wp_get_attachment_image_url($image, 'full');
		}
		
		$output = '<div class="testo">';
		$output .= '<p>';
		$output .= '<img alt="" src="' . esc_url($image) . '">';
		$output .= '</p>';
		$output .= '<h4>' . $title . '<span>' . $sub_title . '</span></h4>';
		$output .= '<p>';
		$output .= do_shortcode($content);
		$output .= '</p>';
		$output .= '</div>';
		
		return $output;
	}
	
	add_shortcode('testimonial', 'testimonial');


/* ============================================================================================================================================= */


	function section_title($atts, $content = "")
	{
		$output = '<h3 class="section-title widget-title">';
		$output .= '<span>';
		$output .= do_shortcode($content);
		$output .= '</span>';
		$output .= '</h3>';
		
		return $output;
	}
	
	add_shortcode('section_title', 'section_title');


/* ============================================================================================================================================= */


	function service($atts, $content = "")
	{
		extract(
			shortcode_atts(
				array(
					'image' => "",
					'title' => ""
				),
				$atts
			)
		);
		
		if (is_numeric($image))
		{
			$image = wp_get_attachment_image_url($image, 'full');
			$image = '<p><img alt="" src="' . esc_url($image) . '"></p>';
		}
		
		if (! empty($title))
		{
			$title = '<h4>' . $title . '</h4>';
		}
		
		$output = '<div class="service">';
		$output .= $image;
		$output .= $title;
		$output .= do_shortcode($content);
		$output .= '</div>';
		
		return $output;
	}
	
	add_shortcode('service', 'service');


/* ============================================================================================================================================= */


	function fun_fact($atts, $content = "")
	{
		extract(
			shortcode_atts(
				array(
					'image' => "",
					'text'  => ""
				),
				$atts
			)
		);
		
		if (is_numeric($image))
		{
			$image = wp_get_attachment_image_url($image, 'full');
			$image = '<p><img alt="" src="' . esc_url($image) . '"></p>';
		}
		
		if (! empty($text))
		{
			$text = '<h4>' . $text . '</h4>';
		}
		
		$output = '<div class="fun-fact">';
		$output .= $image;
		$output .= $text;
		$output .= do_shortcode($content);
		$output .= '</div>';
		
		return $output;
	}
	
	add_shortcode('fun_fact', 'fun_fact');


/* ============================================================================================================================================= */


	function client($atts, $content = "")
	{
		extract(
			shortcode_atts(
				array(
					'image' => "",
					'url'  => ""
				),
				$atts
			)
		);
		
		if (is_numeric($image))
		{
			$image = wp_get_attachment_image_url($image, 'full');
			$image = '<img alt="" src="' . esc_url($image) . '">';
		}
		
		$link_start = "";
		$link_end   = "";
		
		if (! empty($url))
		{
			$link_start = '<a target="_blank" href="' . esc_url($url) . '">';
			$link_end   = '</a>';
		}
		
		$output = '<div class="client">';
		$output .= '<p>';
		$output .= $link_start;
		$output .= $image;
		$output .= $link_end;
		$output .= '</p>';
		$output .= '</div>';
		
		return $output;
	}
	
	add_shortcode('client', 'client');


/* ============================================================================================================================================= */


	function latest_posts($atts, $content = "")
	{
		extract(
			shortcode_atts(
				array(
					'category'     => "",
					'count'        => 5,
					'button_label' => 'See All Posts'
				),
				$atts
			)
		);
		
		$output = "";
		
		// start Query
		$query = new WP_Query(
			array(
				'post_type'      => 'post',
				'posts_per_page' => $count,
				'category_name'  => $category
			)
		);
		if ($query->have_posts()) :
			$output .= '<div class="blog-simple">';
				while ($query->have_posts()) : $query->the_post();
					$post_classes = get_post_class(); // Return value is an array.
					$classes = implode(' ', $post_classes); // Return value is a string.
					$output .= '<article id="post-' . get_the_ID() . '" class="' . $classes . '">';
						$output .= '<div class="hentry-left">';
							$output .= '<div class="entry-date">';
								$output .= '<span class="day">' . get_the_date('d') . '</span>';
								$output .= '<span class="month">' . get_the_date('M') . '</span>';
								$output .= '<span class="year">' . get_the_date('Y') . '</span>';
							$output .= '</div>';
							if (has_post_thumbnail())
							{
								$feat_img     = wp_get_attachment_image_src(get_post_thumbnail_id(), 'life_image_size_5');
								$feat_img_url = $feat_img[0];
								$output .= '<div class="featured-image" style="background-image: url(' . esc_url($feat_img_url) . ');"></div>';
							}
						$output .= '</div>';
						$output .= '<div class="hentry-middle"><h2 class="entry-title"><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2></div>';
						$output .= '<p><a class="post-link" href="' . get_permalink() . '">' . get_the_title() . '</a></p>';
					$output .= '</article>';
				endwhile;
			$output .= '</div>';
		endif;
		wp_reset_postdata();
		// end Query
		
		// Go Blog Button
		$button_url = "";
		$front_page_displays = get_option('show_on_front');
		
		if ($front_page_displays == 'posts')
		{
			$home_url = home_url('/');
			$button_url = $home_url;
		}
		else
		{
			$blog_page_id = get_option('page_for_posts');
			
			if ($blog_page_id)
			{
				$blog_page_url = get_page_link($blog_page_id);
				$button_url = $blog_page_url;
			}
		}
		
		if (! empty($button_url))
		{
			$output .= '<div class="section-launch"><a class="button" href="' . esc_url($button_url) . '">' . $button_label . '</a></div>';
		}
		// end Go Blog Button
		
		return $output;
	}
	
	add_shortcode('latest_posts', 'latest_posts');


/* ============================================================================================================================================= */


	function life_theme_run_shortcode($content)
	{
		global $shortcode_tags;
		
		// Backup current registered shortcodes and clear them all out
		$orig_shortcode_tags = $shortcode_tags;
		
		remove_all_shortcodes();
		
		add_shortcode('social_icon', 'social_icon');
		add_shortcode('contact_form', 'contact_form');
		add_shortcode('quote', 'quote');
		add_shortcode('drop_cap', 'drop_cap');
		// add_shortcode('event_group_title', 'event_group_title');
		add_shortcode('event', 'event');
		add_shortcode('skill', 'skill');
		add_shortcode('testimonial', 'testimonial');
		add_shortcode('section_title', 'section_title');
		add_shortcode('service', 'service');
		add_shortcode('fun_fact', 'fun_fact');
		add_shortcode('client', 'client');
		add_shortcode('latest_posts', 'latest_posts');
		
		// Do the shortcode (only the one above is registered)
		$content = do_shortcode($content);
		
		// Put the original shortcodes back
		$shortcode_tags = $orig_shortcode_tags;
		
		return $content;
	}
	
	add_filter('the_content', 'life_theme_run_shortcode', 7);


/* ============================================================================================================================================= */


	function life_vc_list_categories()
	{
		$categories_array[""] = "";
		$categories           = get_categories();
		
		foreach ($categories as $category)
		{
			$categories_array[$category->name] = $category->slug;
		}
		
		return $categories_array;
	}
	
	
	function life_vc_shortcodes()
	{
		$vc_category = esc_html__("Pixelwars", 'life-shortcodes');
		$vc_icon     = get_template_directory_uri() . '/admin/vc-icon.png';
		
		
		vc_map(
			array(
				"name"        => esc_html__("Service", 'life-shortcodes'),
				"description" => esc_html__("Add service module to content.", 'life-shortcodes'),
				"base"        => "service",
				"weight"      => 12,
				"class"       => "",
				"category"    => $vc_category,
				"icon"        => $vc_icon,
				"params"      => array(
					array(
						"type"        => "attach_image",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Image", 'life-shortcodes'),
						"param_name"  => "image",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Image for service.", 'life-shortcodes')
					),
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Title", 'life-shortcodes'),
						"param_name"  => "title",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__('Service title.', 'my-text-domain')
					),
					array(
						"type"        => "textarea_html",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Description", 'life-shortcodes'),
						"param_name"  => "content",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Description text for service.", 'life-shortcodes')
					)
				)
			)
		);
		
		
		vc_map(
			array(
				"name"        => esc_html__("Fun Fact", 'life-shortcodes'),
				"description" => esc_html__("Add fun fact module to content.", 'life-shortcodes'),
				"base"        => "fun_fact",
				"weight"      => 11,
				"class"       => "",
				"category"    => $vc_category,
				"icon"        => $vc_icon,
				"params"      => array(
					array(
						"type"        => "attach_image",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Image", 'life-shortcodes'),
						"param_name"  => "image",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Image for fun fact.", 'life-shortcodes')
					),
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Text", 'life-shortcodes'),
						"param_name"  => "text",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__('Description text for fun fact.', 'my-text-domain')
					)
				)
			)
		);
		
		
		vc_map(
			array(
				"name"        => esc_html__("Client", 'life-shortcodes'),
				"description" => esc_html__("Add client module to content.", 'life-shortcodes'),
				"base"        => "client",
				"weight"      => 10,
				"class"       => "",
				"category"    => $vc_category,
				"icon"        => $vc_icon,
				"params"      => array(
					array(
						"type"        => "attach_image",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Image", 'life-shortcodes'),
						"param_name"  => "image",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Image for client.", 'life-shortcodes')
					),
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("URL", 'life-shortcodes'),
						"param_name"  => "url",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__('URL address for client.', 'my-text-domain')
					)
				)
			)
		);
		
		
		vc_map(
			array(
				"name"        => esc_html__("Latest Posts", 'life-shortcodes'),
				"description" => esc_html__("Add latest posts module to content.", 'life-shortcodes'),
				"base"        => "latest_posts",
				"weight"      => 9,
				"class"       => "",
				"category"    => $vc_category,
				"icon"        => $vc_icon,
				"params"      => array(
					array(
						"type"        => "dropdown",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Category", 'life-shortcodes'),
						"param_name"  => "category",
						"value"       => life_vc_list_categories(),
						"description" => esc_html__("Select a category or leave blank for all categories.", 'life-shortcodes')
					),
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Post Count", 'life-shortcodes'),
						"param_name"  => "count",
						"value"       => '5',
						"description" => esc_html__('Number of posts to show.', 'my-text-domain')
					),
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Button Label", 'life-shortcodes'),
						"param_name"  => "button_label",
						"value"       => esc_html__('See All Posts', 'life-shortcodes'),
						"description" => esc_html__('Enter text for button label.', 'my-text-domain')
					)
				)
			)
		);
		
		
		vc_map(
			array(
				"name"        => esc_html__("Section Title", 'life-shortcodes'),
				"description" => esc_html__("Add section title to content.", 'life-shortcodes'),
				"base"        => "section_title",
				"weight"      => 8,
				"class"       => "",
				"category"    => $vc_category,
				"icon"        => $vc_icon,
				"params"      => array(
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Title", 'life-shortcodes'),
						"param_name"  => "content",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Title text.", 'life-shortcodes')
					)
				)
			)
		);
		
		
		vc_map(
			array(
				"name"        => esc_html__("Testimonial", 'life-shortcodes'),
				"description" => esc_html__("Add testimonial module to content.", 'life-shortcodes'),
				"base"        => "testimonial",
				"weight"      => 7,
				"class"       => "",
				"category"    => $vc_category,
				"icon"        => $vc_icon,
				"params"      => array(
					array(
						"type"        => "attach_image",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Image", 'life-shortcodes'),
						"param_name"  => "image",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Image for testimonial.", 'life-shortcodes')
					),
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Title", 'life-shortcodes'),
						"param_name"  => "title",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Person's name.", 'life-shortcodes')
					),
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Sub Title", 'life-shortcodes'),
						"param_name"  => "sub_title",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Person's job.", 'life-shortcodes')
					),
					array(
						"type"        => "textarea_html",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Description", 'life-shortcodes'),
						"param_name"  => "content",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Description text for testimonial.", 'life-shortcodes')
					)
				)
			)
		);
		
		
		vc_map(
			array(
				"name"        => esc_html__("Skill", 'life-shortcodes'),
				"description" => esc_html__("Add skill module to content.", 'life-shortcodes'),
				"base"        => "skill",
				"weight"      => 6,
				"class"       => "",
				"category"    => $vc_category,
				"icon"        => $vc_icon,
				"params"      => array(
					array(
						'type'       => 'param_group',
						"heading"    => esc_html__("Values", 'life-shortcodes'),
						'param_name' => 'group',
						'value'      => "",
						'params'     => array(
							array(
								"type"        => "textfield",
								"holder"      => "div",
								"class"       => "",
								"heading"     => esc_html__("Title", 'life-shortcodes'),
								"param_name"  => "title",
								"value"       => "",
								"description" => esc_html__("Skill title.", 'life-shortcodes')
							),
							array(
								"type"        => "textfield",
								"holder"      => "div",
								"class"       => "",
								"heading"     => esc_html__("Percent", 'life-shortcodes'),
								"param_name"  => "percent",
								"value"       => "",
								"description" => esc_html__("Skill percent.", 'life-shortcodes')
							)
						)
					)
				)
			)
		);
		
		
		vc_map(
			array(
				"name"        => esc_html__("Event Group Title", 'life-shortcodes'),
				"description" => esc_html__("Add event group title to content.", 'life-shortcodes'),
				"base"        => "event_group_title",
				"weight"      => 5,
				"class"       => "",
				"category"    => $vc_category,
				"icon"        => $vc_icon,
				"as_parent"               => array('only' => 'vc_icon'),
				"content_element"         => true,
				"show_settings_on_create" => true,
				"is_container"            => true,
				"params"      => array(
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Event Group Title", 'life-shortcodes'),
						"param_name"  => "text",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Title text.", 'life-shortcodes')
					)
				),
				"js_view" => 'VcColumnView'
			)
		);
		
		
		vc_map(
			array(
				"name"        => esc_html__("Event", 'life-shortcodes'),
				"description" => esc_html__("Add event module to create timeline.", 'life-shortcodes'),
				"base"        => "event",
				"weight"      => 4,
				"class"       => "",
				"category"    => $vc_category,
				"icon"        => $vc_icon,
				"params"      => array(
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Title", 'life-shortcodes'),
						"param_name"  => "title",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Title text.", 'life-shortcodes')
					),
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Sub Title", 'life-shortcodes'),
						"param_name"  => "sub_title",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Sub title text.", 'life-shortcodes')
					),
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Date", 'life-shortcodes'),
						"param_name"  => "date",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Enter date.", 'life-shortcodes')
					),
					array(
						"type"        => "checkbox",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Make Current", 'life-shortcodes'),
						"param_name"  => "current",
						"value"       => "",
						"description" => esc_html__("Select if this is a current event.", 'life-shortcodes')
					),
					array(
						"type"        => "textarea_html",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Description", 'life-shortcodes'),
						"param_name"  => "content",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Description text for event.", 'life-shortcodes')
					)
				)
			)
		);
		
		
		vc_map(
			array(
				"name"        => esc_html__("Social Icon", 'life-shortcodes'),
				"description" => esc_html__("Add social media icon to content.", 'life-shortcodes'),
				"base"        => "social_icon",
				"weight"      => 3,
				"class"       => "",
				"category"    => $vc_category,
				"icon"        => $vc_icon,
				"params"      => array(
					array(
						'type'       => 'param_group',
						'value'      => "",
						'param_name' => 'group',
						'params'     => array(
							array(
								"type"        => "dropdown",
								"holder"      => "div",
								"class"       => "",
								"heading"     => esc_html__("Type", 'life-shortcodes'),
								"param_name"  => "type",
								"value"       => array("", 'facebook', 'twitter', 'linkedin', 'google-plus', 'pinterest', 'github', 'behance', 'dribbble', 'instagram', 'lastfm', 'vimeo', 'forrst', 'skype', 'picasa', 'youtube', 'flickr', 'tumblr', 'blogger', 'delicious', 'digg', 'friendfeed', 'wordpress', 'foursquare', 'xing', 'soundcloud', 'slideshare', 'fivehundredpx', 'weibo', 'stack-overflow', 'vine', 'vkontakte', 'bloglovin', 'rss'),
								"description" => esc_html__("Select social media.", 'life-shortcodes')
							),
							array(
								"type"        => "textfield",
								"holder"      => "div",
								"class"       => "",
								"heading"     => esc_html__("URL", 'life-shortcodes'),
								"param_name"  => "url",
								"value"       => esc_html__("", 'life-shortcodes'),
								"description" => esc_html__("Enter url address.", 'life-shortcodes')
							),
							array(
								"type"        => "dropdown",
								"holder"      => "div",
								"class"       => "",
								"heading"     => esc_html__("Same Tab", 'life-shortcodes'),
								"param_name"  => "same_tab",
								"value"       => array('no', 'yes'),
								"description" => esc_html__("Open link in same tab.", 'life-shortcodes')
							)
						)
					)
				)
			)
		);
		
		
		vc_map(
			array(
				"name"        => esc_html__("Quote", 'life-shortcodes'),
				"description" => esc_html__("Add quote module to content.", 'life-shortcodes'),
				"base"        => "quote",
				"weight"      => 2,
				"class"       => "",
				"category"    => $vc_category,
				"icon"        => $vc_icon,
				"params"      => array(
					array(
						"type"        => "dropdown",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Align", 'life-shortcodes'),
						"param_name"  => "align",
						"value"       => array("", 'alignleft', 'alignright'),
						"description" => esc_html__("Align quote.", 'life-shortcodes')
					),
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Name", 'life-shortcodes'),
						"param_name"  => "name",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Person's name.", 'life-shortcodes')
					),
					array(
						"type"        => "textarea_html",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Description", 'life-shortcodes'),
						"param_name"  => "content",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Description text for quote.", 'life-shortcodes')
					)
				)
			)
		);
		
		
		vc_map(
			array(
				"name"        => esc_html__("Contact Form", 'life-shortcodes'),
				"description" => esc_html__("Add theme contact form to content.", 'life-shortcodes'),
				"base"        => "contact_form",
				"weight"      => 1,
				"class"       => "",
				"category"    => $vc_category,
				"icon"        => $vc_icon,
				"params"      => array(
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("To", 'life-shortcodes'),
						"param_name"  => "to",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Enter your email address.", 'life-shortcodes')
					),
					array(
						"type"        => "textfield",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Subject", 'life-shortcodes'),
						"param_name"  => "subject",
						"value"       => esc_html__("", 'life-shortcodes'),
						"description" => esc_html__("Enter email subject.", 'life-shortcodes')
					),
					array(
						"type"        => "dropdown",
						"holder"      => "div",
						"class"       => "",
						"heading"     => esc_html__("Captcha", 'life-shortcodes'),
						"param_name"  => "captcha",
						"value"       => array('no', 'yes'),
						"description" => esc_html__("Captcha for contact form.", 'life-shortcodes')
					)
				)
			)
		);
	}
	
	add_action('vc_before_init', 'life_vc_shortcodes');

?>