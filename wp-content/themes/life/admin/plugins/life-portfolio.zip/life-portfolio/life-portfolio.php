<?php
/*
Plugin Name: Life Portfolio
Plugin URI:  http://www.pixelwars.org
Description: Portfolio posts.
Version:     1.0
Author:      Pixelwars
Author URI:  http://www.pixelwars.org
License:     ThemeForest License
Text Domain: life-portfolio
Domain Path: /languages/
*/


/* ============================================================================================================================================= */


	// Don't load directly
	
	if (! defined('ABSPATH'))
	{
		die('-1');
	}


/* ============================================================================================================================================= */


	function life_portfolio_load_plugin_textdomain()
	{
		load_plugin_textdomain(
			'life-portfolio',
			false,
			dirname(plugin_basename(__FILE__)) . '/languages'
		);
	}
	
	add_action('init', 'life_portfolio_load_plugin_textdomain');


/* ============================================================================================================================================= */


	function life_portfolio_after_setup_theme()
	{
		add_theme_support(
			'post-thumbnails',
			array('portfolio')
		);
	}
	
	add_action('after_setup_theme', 'life_portfolio_after_setup_theme', 11);


/* ============================================================================================================================================= */


	function life_create_post_type__portfolio()
	{
		register_post_type(
			'portfolio',
			array(
				'label'         => esc_html__('Portfolio', 'life-portfolio'),
				'public' 		=> true,
				'menu_position' => 5,
				'supports'      => array(
					'title',
					'editor',
					'thumbnail',
					'excerpt',
					'comments',
					'post-formats'
				)
			)
		);
	}
	
	add_action('init', 'life_create_post_type__portfolio');
	
	
	function life_taxonomy__portfolio()
	{
		register_taxonomy(
			'portfolio-category',
			array('portfolio'),
			array(
				'label' 	        => esc_html__('Portfolio Categories', 'life-portfolio'),
				'hierarchical' 		=> true,
				'show_admin_column' => true
			)
		);
	}
	
	add_action('init', 'life_taxonomy__portfolio');
	
	
	function life_taxonomy_filter_portfolio()
	{
		global $typenow;
		
		if ($typenow == 'portfolio')
		{
			$filters = array('portfolio-category');
			
			foreach ($filters as $tax_slug)
			{
				$tax_obj  = get_taxonomy($tax_slug);
				$tax_name = $tax_obj->labels->name;
				$terms 	  = get_terms($tax_slug);
				
				echo '<select name="' . esc_attr($tax_slug) . '" id="' . esc_attr($tax_slug) . '" class="postform">';
				
					echo '<option value="">' . esc_html__('All', 'life-portfolio') . ' ' . esc_html($tax_name) . '</option>';
					
					foreach ($terms as $term)
					{
						echo '<option value=' . $term->slug, @$_GET[$tax_slug] == $term->slug ? ' selected="selected"' : '','>' . esc_html($term->name) .' (' . esc_html($term->count) . ')</option>';
					}
				
				echo '</select>';
			}
		}
	}
	
	add_action('restrict_manage_posts', 'life_taxonomy_filter_portfolio');

?>